<?php
$header = <<<_END
<header>
<img id="Logo" src="imageweb\logo.png" alt="Logo_Orion" />				
<h1 id="Titre">Astrologie Orion</h1>
<nav>
<ul id="browse">
<li id="browse-Acc"><a href="index.php">Accueil</a></li>
<li id="browse-Signes"><a href="Signes.php">Signes</a></li>
<li id="browse-Desc"><a href="Description.php">Description</a></li>
<li id="browse-Traits"><a href="Traits.php">Traits</a></li>
<li id="browse-HoroVirt"><a href="HoroVirt.php">Horoscope virtuel</a></li>
<li id="browse-Produits"><a href="Produits.php">Produits</a></li>
</ul>
</nav>
</header>
_END;
echo $header;
?>


