<?php
$footer = <<<_END
<footer>
<span class="credits">				 
<ul>					
<li><small><sup>&copy </sup>Copyright Astrologie Orion MMXIX</small></li>
<li>Rejoindre <a href="mailto:mdmFantastique@gmail.com">Madame Fantastique</a></li>
<li>Dernière Modification : 2019-04-26 </li>
</ul>
</span>
</footer>
_END;
echo $footer;
?>

