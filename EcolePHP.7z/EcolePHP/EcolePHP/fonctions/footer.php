<?php

$footer = <<<_END
        <br>
        <form action="index.php">
            <input type="submit" value="Logout" name="logout" id="logout"/>
        </form>        
</body>
</html>        
_END;


echo $footer;
?>

